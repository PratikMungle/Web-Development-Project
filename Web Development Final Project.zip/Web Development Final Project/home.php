<?php
session_start();
 ?>

<!DOCTYPE html>
<html>
<head><title>E-Store | Electronic goods dealer</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <link href="https://fonts.googleapis.com/css?family=Open Sans" rel="stylesheet">

<style type="text/css">
	

</style>
</head>
<body style="font-family: Open Sans">
<?php
if(isset($_SESSION['id'])){ 
	require 'header_logged_in.php';
	?>
<div  class="container" style="margin-top: 60px;">
<b>
<?php
echo "Hi ".$_SESSION['name'];
 ?>
<div class="container" style="margin-top: 50px; margin-bottom: 100px">
	<div class="row row-style-login-page-pannel">
		<div class=" col-md-4 col-sm-6 col-xs-12">
			<div class="panel panel-default">
				<div class="panel-heading"># 1</div>
				<div class="panel-body">
					<center><img  class="img-responsive"  src="includes/oneplus5t.jpg">
                                            20+16 MP Dual rear camera | 16 MP front camera<br>
                                            15.26 centimeters (6.01-inch) Full HD+ capacitive touchscreen<br>
                                            4GB RAM | 64GB storage</center>
					<button class="btn btn-primary form-control" type="button" value="Submit"  name="btn" data-toggle="modal" data-target="#all">Add to Cart</button>
				</div>
			</div>
		</div>	

		<div class=" col-md-4 col-sm-6 col-xs-12">
			<div class="panel panel-default">
				<div class="panel-heading"># 2</div>
				<div class="panel-body">
					<center><img  class="img-responsive" src="includes/iphonex.jpg">
                                        6.5-inch Super Retina display (OLED) with HDR<br>
                                        IP68 dust and water resistant (maximum depth of 2 meters up to 30 minutes)<br>
                                        12MP dual cameras with dual OIS and 7MP TrueDepth front camera</center>
					<button class="btn btn-primary form-control" type="button" value="Submit"  name="btn" data-toggle="modal" data-target="#all">Add to Cart</button>
				</div>
			</div>
		</div>

		<div class=" col-md-4 col-sm-6 col-xs-12">
			<div class="panel panel-default">
				<div class="panel-heading"># 3</div>
				<div class="panel-body" >
					<center><img  class="img-responsive" src="includes/samsungs8.jpg">
					  Quad rear camera - 64MP OIS F2.0 tele camera + 12MP F2.2 ultra wide + 12MP (2PD) OIS F1.8 wide
                                          16.95 centimeters (6.7-inch) display with capacitive touchscreen
                                         8GB RAM | 128GB internal memory</center>
					<button class="btn btn-primary form-control" type="button" value="Submit"  name="btn" data-toggle="modal" data-target="#all">Add to Cart</button>
				</div>
			</div>
		</div>	

		<div class=" col-md-4 col-sm-6 col-xs-12">
			<div class="panel panel-default">
				<div class="panel-heading"># 4</div>
				<div class="panel-body" >
					<center><img  class="img-responsive" src="includes/iphone7s.jpg">
                                        4.7-inch Retina HD LCD display<br>
                                        Single 12MP Wide camera with Auto HDR and 4K video up to 30fps<br>
                                        7MP FaceTime HD camera with 1080p video</center>
					<button class="btn btn-primary form-control" type="button" value="Submit"  name="btn" data-toggle="modal" data-target="#all">Add to Cart</button>
				</div>
			</div>
		</div>	

		<div class=" col-md-4 col-sm-6 col-xs-12">
			<div class="panel panel-default">
				<div class="panel-heading"># 5</div>
				<div class="panel-body" >
					<center><img  class="img-responsive" src="includes/oneplus3t.jpg">
                                        Rear Camera - 48MP (Primary) + 8MP (Tele-photo)+16MP (Ultrawide) Front Camera - 16 MP POP-UP Camera<br>
                                        16.9 centimeters (6.67-inch) multi-touch capacitive touchscreen<br>
                                        Memory, Storage and SIM: 8GB RAM 256GB internal memory </center>
					<button class="btn btn-primary form-control" type="button" value="Submit"  name="btn" data-toggle="modal" data-target="#all">Add to Cart</button>
				</div>
			</div>
		</div>	

		<div class=" col-md-4 col-sm-6 col-xs-12">
			<div class="panel panel-default">
				<div class="panel-heading"># 6</div>
				<div class="panel-body">
					<center><img  class="img-responsive" src="includes/oppoa57.jpg">
                                         12+8+2+2MP rear camera 8MP AI front camera<br>
                                         16.5 centimeters (6.5-inch) <br>
                                         4GB RAM | 64GB internal memory expandable up to 256GB</center>
					<button class="btn btn-primary form-control" type="button" value="Submit"  name="btn" data-toggle="modal" data-target="#all">Add to Cart</button>
				</div>
			</div>
		</div>	
	</div>
</div>

<?php } else { 
	header('location: index.php'); 
}
?>
    
</body>
</html>
